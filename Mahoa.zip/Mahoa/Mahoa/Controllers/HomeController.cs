﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Mahoa.Models;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace LanChatSocket.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Hiển thị trang Index
        public IActionResult Index()
        {
            return View();
        }

        // Phương thức để gửi tin nhắn qua socket client
        [HttpPost]
        public async Task<IActionResult> SendMessage([FromBody] MessageModel model)
        {
            try
            {
                var client = new SocketClient(model.Ip, 5001); // Kết nối tới IP và port
                await client.SendMessageAsync(model.Message);  // Gửi tin nhắn
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Lỗi khi gửi tin nhắn: {ex.Message}");
                return StatusCode(500, "Không thể gửi tin nhắn");
            }
        }

        // Phương thức để nhận tin nhắn qua Server-Sent Events (SSE)
        [HttpGet]
        public async Task GetMessages()
        {
            Response.ContentType = "text/event-stream";
            Response.Headers["Cache-Control"] = "no-cache";
            Response.Headers["Connection"] = "keep-alive";

            // Một cơ chế để thoát khỏi vòng lặp khi không còn tin nhắn mới hoặc khi client ngắt kết nối
            while (!HttpContext.RequestAborted.IsCancellationRequested)
            {
                if (SocketServer.ReceivedMessages.TryDequeue(out string message))
                {
                    await Response.WriteAsync($"data: {message}\n\n");
                    await Response.Body.FlushAsync();
                }
                else
                {
                    await Task.Delay(500);  // Delay nhỏ để giảm tải cho CPU
                }
            }
        }

        // Model để nhận thông tin IP và Message từ client
        public class MessageModel
        {
            public string Ip { get; set; }
            public string Message { get; set; }
        }
    }
}
