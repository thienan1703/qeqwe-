﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

public class SocketClient
{
    private readonly string _serverIp;
    private readonly int _port;
    private static readonly string key = "aaaaabbbbbcccccd"; // 16 ký tự

    public SocketClient(string serverIp, int port)
    {
        _serverIp = serverIp;
        _port = port;
    }

    public async Task SendMessageAsync(string message)
    {
        try
        {
            using (var client = new TcpClient())
            {
                await client.ConnectAsync(_serverIp, _port);
                var stream = client.GetStream();
                byte[] data = Encrypt(message, key);
                await stream.WriteAsync(data, 0, data.Length);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }

    private static byte[] Encrypt(string text, string key)
    {
        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(key);
            aes.IV = new byte[16];
            using (var encryptor = aes.CreateEncryptor())
            {
                byte[] input = Encoding.UTF8.GetBytes(text);
                return encryptor.TransformFinalBlock(input, 0, input.Length);
            }
        }
    }
}
