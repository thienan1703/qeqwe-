﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

public class SocketServer
{
    private readonly int _port;
    private TcpListener _server;
    private List<TcpClient> _clients = new List<TcpClient>();
    public static ConcurrentQueue<string> ReceivedMessages = new ConcurrentQueue<string>();
    private static readonly string key = "aaaaabbbbbcccccd"; // 16 ký tự

    public SocketServer(int port)
    {
        _port = port;
    }

    public async Task StartAsync()
    {
        _server = new TcpListener(IPAddress.Any, _port);
        _server.Start();
        Console.WriteLine($"Server dang chay tren cong:  {_port}...");

        while (true)
        {
            var client = await _server.AcceptTcpClientAsync();
            _clients.Add(client);
            _ = Task.Run(() => HandleClient(client));
        }
    }

    private async Task HandleClient(TcpClient client)
    {
        var stream = client.GetStream();
        byte[] buffer = new byte[1024];

        while (true)
        {
            int byteCount = await stream.ReadAsync(buffer, 0, buffer.Length);
            if (byteCount == 0) break;

            string receivedMessage = Decrypt(buffer[..byteCount], key);
            Console.WriteLine($"Receive: {receivedMessage}");

            ReceivedMessages.Enqueue(receivedMessage);

            foreach (var otherClient in _clients)
            {
                if (otherClient != client)
                {
                    var otherStream = otherClient.GetStream();
                    byte[] response = Encrypt(receivedMessage, key);
                    await otherStream.WriteAsync(response, 0, response.Length);
                }
            }
        }
        client.Close();
        _clients.Remove(client);
    }
    //giai ma 
    private static string Decrypt(byte[] encryptedData, string key)
    {
        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(key);
            aes.IV = new byte[16];
            using (var decryptor = aes.CreateDecryptor())
            {
                byte[] decrypted = decryptor.TransformFinalBlock(encryptedData, 0, encryptedData.Length);
                return Encoding.UTF8.GetString(decrypted);
            }
        }
    }
    //ma hoa 
    private static byte[] Encrypt(string text, string key)
    {
        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(key);
            aes.IV = new byte[16];
            using (var encryptor = aes.CreateEncryptor())
            {
                byte[] input = Encoding.UTF8.GetBytes(text);
                return encryptor.TransformFinalBlock(input, 0, input.Length);
            }
        }
    }
}
